# Bacha Companion — Kit PWA + Cloud + Telegram

Kit complet pour transformer la Companion en :
- **PWA** installable comme une app sur iPhone/Android
- **Cloud** partagé via Netlify Blobs (plus de perte de données)
- **Notifications Telegram** pour l'équipe

---

## 📁 Ce qui est dans le kit

```
bacha-companion-kit/
├── manifest.json              → À mettre à la racine du site
├── sw.js                      → Service worker (racine)
├── netlify.toml               → Config Netlify (racine)
├── package.json               → Dépendance @netlify/blobs (racine)
├── icons/
│   ├── icon-192.png
│   ├── icon-512.png
│   └── apple-touch-icon.png
├── netlify/
│   └── functions/
│       ├── data.js            → API cloud storage
│       └── notify.js          → API Telegram
└── SNIPPETS-A-INTEGRER.html   → Code à coller dans ton index.html
```

---

## 🚀 Installation en 6 étapes

### 1. Dépose les fichiers dans ton projet

La structure finale de ton projet doit ressembler à :
```
ton-projet/
├── index.html              (ton fichier existant, modifié — voir étape 2)
├── manifest.json
├── sw.js
├── netlify.toml
├── package.json
├── icons/...
└── netlify/functions/...
```

### 2. Modifie ton `index.html`

Ouvre `SNIPPETS-A-INTEGRER.html` et colle :
- **Bloc 1** dans le `<head>` de ton `index.html`
- **Bloc 2** juste avant la balise `</body>`
- **Bloc 3** dans ton `<script>` principal (il ajoute les fonctions `cloudGet/Set`, `notify`, etc.)

### 3. Remplace tes appels localStorage par les helpers cloud

**Avant :**
```js
const stock = JSON.parse(localStorage.getItem('stock') || '{}');
localStorage.setItem('stock', JSON.stringify(stock));
```

**Après :**
```js
const stock = (await migrateToCloud('stock')) || { items: [] };
await cloudSet('stock', stock);
```

👉 Fais-le progressivement, clé par clé (`stock`, `menu`, `obd`, `alcool`, `evenements`...).
La fonction `migrateToCloud` transfère automatiquement les données existantes de localStorage vers le cloud la première fois.

### 4. Installe la dépendance et déploie

Sur ton ordi, dans le dossier du projet :
```bash
npm install
```
Puis déploie comme d'habitude (drag & drop sur Netlify ou `git push`).

### 5. Crée le bot Telegram

1. Dans Telegram, cherche **@BotFather**, tape `/newbot`, suis les instructions.
2. Copie le **token** (format `123456:ABC-DEF...`).
3. Crée un groupe Telegram, ajoute ton bot et tous les employés.
4. Envoie un message dans le groupe.
5. Ouvre dans le navigateur : `https://api.telegram.org/botTON_TOKEN/getUpdates`
6. Cherche `"chat":{"id":-100...}` et copie l'ID (avec le `-`).

### 6. Configure les variables d'environnement Netlify

Dans **Netlify → Site settings → Environment variables**, ajoute :

| Variable | Valeur |
|---|---|
| `TELEGRAM_TOKEN` | Le token de @BotFather |
| `TELEGRAM_CHAT_ID` | L'ID du groupe (ex: `-1001234567890`) |
| `APP_PASSWORD` | *(optionnel)* Mot de passe partagé du staff |

Redéploie pour appliquer.

---

## ✅ Tests à faire après déploiement

1. **PWA** : ouvre le site sur ton iPhone → Partager → Ajouter à l'écran d'accueil. L'app doit s'ouvrir en plein écran avec l'icône B dorée.
2. **Cloud** : modifie un stock sur ton téléphone, ouvre l'app sur un autre appareil, les données doivent être synchronisées.
3. **Telegram** : déclenche `notify('Test', 'normal', 'Mathis')` depuis la console → message dans le groupe.

---

## 🔔 Idées de déclencheurs à brancher

Dans tes fonctions existantes, ajoute des appels `notify()` :

```js
// Stock bas
if (item.quantity < item.threshold) {
  notify(`Stock bas : ${item.name} (${item.quantity} restants)`, 'high');
}

// Commande OBD validée
notify(`Commande OBD envoyée — ${articles.length} articles`, 'normal', currentUser);

// Événement imminent
notify(`📅 ${event.name} demain à ${event.time}`, 'normal');

// Maintenance
notify(`🔧 Détartrage SP9 dû aujourd'hui`, 'high');
```

---

## ⚠️ Points importants

- **Sauvegarde** ton `index.html` actuel avant de le modifier.
- **Les données cloud ne sont PAS publiques** : la Function vérifie le mot de passe `APP_PASSWORD` si tu l'as défini.
- **Sur iPhone**, pour que la PWA fonctionne bien, elle doit être installée via Safari (pas Chrome iOS).
- Le service worker met en cache les assets, donc une mise à jour peut prendre quelques secondes. Si tu déploies une grosse refonte, incrémente `CACHE_VERSION` dans `sw.js`.

---

## 🤖 Prompt prêt pour Cowork

Si tu veux déléguer tout ça à Cowork, copie-colle ce prompt :

> J'ai un projet Netlify `bacha-companion` avec un `index.html` à la racine déployé sur Netlify via drag & drop. Je veux que tu :
> 1. Télécharges le kit du dossier `bacha-companion-kit`
> 2. Copies tous les fichiers à la racine de mon projet (sauf SNIPPETS-A-INTEGRER.html)
> 3. Intègres les 3 blocs de SNIPPETS-A-INTEGRER.html dans mon index.html aux bons endroits
> 4. Fasses `npm install`
> 5. Crées un ZIP du projet prêt pour upload Netlify
> 6. M'ouvres Netlify dans Chrome et guides la config des variables d'environnement
