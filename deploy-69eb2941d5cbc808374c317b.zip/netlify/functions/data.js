// /.netlify/functions/data
// Stockage cloud JSON via Netlify Blobs
// Usage :
//   GET    /.netlify/functions/data?key=stock        -> lit la clé "stock"
//   POST   /.netlify/functions/data?key=stock        -> écrit la clé "stock" (body = JSON)
//   DELETE /.netlify/functions/data?key=stock        -> supprime la clé
//   GET    /.netlify/functions/data?action=list      -> liste toutes les clés
//   GET    /.netlify/functions/data?action=pullAll   -> renvoie tout en un objet { key: value }

import { getStore } from '@netlify/blobs';

// Protection optionnelle par mot de passe partagé (variable d'env APP_PASSWORD)
function checkAuth(req) {
  const expected = process.env.APP_PASSWORD;
  if (!expected) return true; // pas de mot de passe configuré
  // 1) Header standard
  const header = req.headers.get('x-app-password');
  if (header === expected) return true;
  // 2) Fallback query string (uniquement pour sendBeacon qui n'autorise pas de header custom)
  try {
    const url = new URL(req.url);
    const q = url.searchParams.get('pw');
    if (q === expected) return true;
  } catch (_) {}
  return false;
}

// CORS — pratique si jamais l'app est ouverte depuis un autre domaine
const CORS = {
  'access-control-allow-origin': '*',
  'access-control-allow-methods': 'GET,POST,DELETE,OPTIONS',
  'access-control-allow-headers': 'content-type,x-app-password'
};

export default async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: CORS });
  }
  if (!checkAuth(req)) {
    return new Response(JSON.stringify({ error: 'unauthorized' }), {
      status: 401,
      headers: { 'content-type': 'application/json', ...CORS }
    });
  }

  const store = getStore('bacha-data');
  const url = new URL(req.url);
  const key = url.searchParams.get('key');
  const action = url.searchParams.get('action');

  try {
    if (action === 'list') {
      const { blobs } = await store.list();
      return new Response(JSON.stringify({ keys: blobs.map((b) => b.key) }), {
        headers: { 'content-type': 'application/json', ...CORS }
      });
    }

    if (action === 'pullAll') {
      const { blobs } = await store.list();
      const bundle = {};
      // Parallélise les lectures
      await Promise.all(
        blobs.map(async (b) => {
          try {
            const v = await store.get(b.key, { type: 'json' });
            if (v !== null && v !== undefined) bundle[b.key] = v;
          } catch (_) {
            // blob corrompu → on saute
          }
        })
      );
      return new Response(JSON.stringify(bundle), {
        headers: { 'content-type': 'application/json', ...CORS }
      });
    }

    if (!key) {
      return new Response(JSON.stringify({ error: 'key required' }), {
        status: 400,
        headers: { 'content-type': 'application/json', ...CORS }
      });
    }

    if (req.method === 'GET') {
      const data = await store.get(key, { type: 'json' });
      return new Response(JSON.stringify(data ?? null), {
        headers: { 'content-type': 'application/json', ...CORS }
      });
    }

    if (req.method === 'POST') {
      const body = await req.json();
      await store.setJSON(key, body);
      return new Response(JSON.stringify({ ok: true, key }), {
        headers: { 'content-type': 'application/json', ...CORS }
      });
    }

    if (req.method === 'DELETE') {
      await store.delete(key);
      return new Response(JSON.stringify({ ok: true, key }), {
        headers: { 'content-type': 'application/json', ...CORS }
      });
    }

    return new Response('method not allowed', { status: 405, headers: CORS });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { 'content-type': 'application/json', ...CORS }
    });
  }
};
