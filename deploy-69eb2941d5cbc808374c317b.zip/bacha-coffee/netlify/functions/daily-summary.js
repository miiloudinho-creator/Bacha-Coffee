// /.netlify/functions/daily-summary
// Scheduled Function — Récap quotidien Telegram à 8h (Paris)
// Cron : 0 6 * * * (UTC) = 8h heure de Paris (CEST, UTC+2)

import { getStore } from '@netlify/blobs';

// ═══ DONNÉES CAFÉS (miroir de index.html) ═══
const CRAW = "AC0001 Sidamo Mountain|AC0002 Kaffa Kaldi Supreme|AC0003 Yirgacheffe Heirloom|AC0004 Yirgacheffe Decaffeinated|AC0100 Mount Kenya|AC0101 Black Pearl|AC0102 Muiri Flame|AC0200 Wagagai Crest|AC0201 Moon Mountain|AC0300 Rwanda Superior|AC0301 Nyamasheke Highland|AC0400 Bantu Secret|AC0401 Kinshasa Night|AC0500 Zanzibar Gold|AC0600 Kibira Rain|AC0700 Mpika Jewel|AC0800 Rukuru River|AC1000 Grand Moka Matari|AC2000 Sao Bento|AC2001 Carmo|AC2002 Lagoa|AC2003 Sao Silvestre|AC2004 Camocim|AC2005 Camocim Jacu Bird|AC2006 Sweet Santos Decaffeinated|AC2007 Paraiso Gold|AC2100 Magdalena|AC2101 Magdalena Decaffeinated|AC2102 Kachalu|AC2103 Guayacan|AC2400 San Cristobal|AC2401 Vilcabamba|AC2402 Inca Sun|AC2500 Rosenheim|AC2501 Tunki Valley|AC2502 Bagua Cloud Superior|AC2503 Rosenheim Decaffeinated|AC2600 Villa Oriente|AC2601 La Frontera|AC3000 Sierra Madre|AC3001 Lampocoy|AC3100 Los Andes Pacamara|AC3101 La Reforma|AC3200 Volcan Azul|AC3201 Volcan Azul Red Honey|AC3202 Volcan Azul Gesha|AC3203 Naranjo Mountain|AC3300 Marcala Excellence|AC3301 Copantillo Prestige|AC3400 Boquete Highlands|AC3401 La Berlina Gesha|AC3500 Grand Maragogype|AC3501 Flores del Cafe Superior|AC3600 Blue Mountain Wallenford|AC3601 Blue Mountain Gold Cup|AC3700 Elephant Maragogype|AC3701 El Flamingo|AC3702 El Flamingo Decaffeinated|AC3800 Turquino|AC3801 Serrano Superior|AC3900 Dominican Republic Superior|AC3901 Caribbean Mountain|AC4000 Toba Mist|AC4001 Wild Kopi Luwak Supreme|AC4002 Java Blue|AC4100 Monsoon Secret|AC4200 Guizhou Plateau|AC4201 Honey Dragon|AC4300 Pang Khon|AC4400 Star of Hanoi|AC4500 Mount Everest|AC4600 Danu Gold|AC5001 Kona Paradise Meadows|AC5002 Kona Cornwell|AC5100 Skybury|AC5200 Sigri Excellence|AC5201 Sigri Jewel|AC8000 Nairobi Rain|AC8001 Three Volcanoes|AC8002 Burundi Express|AC8003 Yellow Leopard|AC8004 Saigon Morning|AC8005 Hilltribe|AC8006 Mombasa Song|AC8007 Monkey Warrior|AC8008 Malabar Delight|AC8009 Blue Dawn|AC8010 Mara Plains|AC8011 Sweet Kunming|AC8012 Surabaya Gold|AC8013 Elephant Queen|AC8014 Copacabana|AC8015 Out of Africa|AC8100 Blue Mountain Mist|AC8101 World Cup|AC8102 Zambezi Express|AC8103 Machu Picchu|AC8104 Maui Sun|AC8105 Kona Snow|AC8106 Montecristo|AC8107 Roman Holiday|AC8108 Kampala Dream|AC8109 Bird of Paradise|AC8110 Black Elephant|AC8111 Happy Arabia|AC8200 Black Moon|AC8201 African Queen|AC8202 Red Bison|AC8203 White Nile|AC8204 Calisalsa|AC8205 Happy Bogota|AC8206 White Peaks|AC8207 Rio Bravo|AC8208 Sweet Abyssinia|AC8209 Darling Havana|AC8210 Over the Andes|AC8211 Tarantella|AC8212 Elephant King|AC8213 Oxapampa Valley Decaffeinated|AC8214 Blue Macaw Decaffeinated|AC8215 Lost Chiapas Decaffeinated|AC8216 Red Orchid Decaffeinated|AC8217 Marrakech Express Decaffeinated|AC9000 Aztec Night|AC9001 Tolteca Chocolate|AC9002 Caramelo Morning|AC9003 Happy Gianduja|AC9004 Highland Snow|AC9005 Siena Breakfast|AC9006 Vienna Dawn|AC9007 Black Amarena|AC9008 Winter Party|AC9009 Royal Pistachio|AC9010 Seville Orange|AC9011 Magic Istanbul|AC9012 Sweet Mexico|AC9013 Maple Dance|AC9014 Sugar Moon|AC9015 1910|AC9016 Orange Sky|AC9017 Rio Azul|AC9018 Mardi Gras|AC9019 Eternal Marrakech|AC9020 November Moon|AC9021 Carnevale|AC9022 Land of Mist|AC9023 Sweet Salzburg|AC9024 Grand Torino|AC9025 Portobello Road|AC9026 Chocolate Hill|AC9027 Terebinthia|AC9028 Blue Danube|AC9029 Walnut Hill|AC9030 Ponte Vecchio|AC9031 Song of Summer|AC9032 Sweet Nocciola|AC9033 Milano Morning|AC9034 Night in Venice|AC9035 Grand Borgia|AC9036 Birthday Wish|AC9037 Forever Montezuma|AC9038 I Love Paris|AC9039 New York New York|AC9040 Brightberry|AC9041 Marhaba|AC9042 Sweetheart|AC9043 Bella Giornata|AC9044 Fleur du Maroc|AC9045 Turkish Delight|AC9046 Black Panther|AC9047 Hola Colombia|AC9048 Forbidden Yunnan|AC9049 Safari Sky|AC9050 Route to Kigali|AC9051 Okapi Forest|AC9052 Dragon Dance|AC9053 Maya Oro|AC9054 Honey Moon|AC9055 Wild Fire|AC9056 Marocchissimo!|AC9057 Montebello|AC9058 Road to Gondar|AC9059 Sweet Siesta|AC9060 Tembo Warrior|AC9061 Jambo! Jambo!|AC9062 Flame Tree|AC9063 Savannah Sun|AC9064 Eternal Rio|AC9065 Amazonas|AC9066 Grand Vizier|AC9067 Singapore Morning|AC9068 Orangerie|AC9069 Via Toscana|AC9070 Autumn Holiday|AC9071 Strawberry Moon|AC9072 Golden Eagle|AC9073 Song of Saba|AC9074 Baraka Decaffeinated|AC9075 Midnight Sun Decaffeinated|AC9076 Kahwa! Kahwa! Decaffeinated|AC9077 Brigadeiro Decaffeinated|AC9078 Night in Moka Decaffeinated|AC9079 Terra Dolce Decaffeinated|AC9080 Addis Ababa Decaffeinated|AC9081 Marrakech Morning|AC9082 Moroccan Sahara|AC9083 King of Africa|AC9800 Samba Nights";

// Rotation des cafés du jour — même logique que getMB() dans index.html
const MB_START = new Date(2026, 2, 2); // 2 mars 2026
const MB_RAW = "AC3000,AC8212|AC9005,AC9036|AC9057,AC9055|AC8211,AC9024|AC3300,AC4300|AC3400,AC3701|AC2102,AC9042|AC8100,AC3601|AC0500,AC1000|AC2401,AC2400|AC8105,AC5002|AC3101,AC9031|AC9062,AC8111|AC9019,AC9066|AC4002,AC9081|AC9056,AC2006|AC3801,AC8008|AC9083,AC9082|AC8217,AC8104|AC8216,AC3501|AC2601,AC8210|AC3202,AC8202|AC8106,AC8109|AC3301,AC3702|AC9044,AC0200|AC5001,AC8215|AC2402,AC9014,AC3201|AC2500,AC8103,AC4600|AC0003,AC8208,AC3500|AC9010,AC9074,AC8215|AC3203,AC9034|AC3700,AC8209|AC9021,AC9043,AC2007|AC9015,AC2401|AC2100,AC9046|AC0201,AC2502|AC9018,AC9064|AC8002,AC0600|AC2501,AC9040|AC9025,AC9039|AC8004,AC4400|AC0001,AC9080|AC9008,AC9020|AC9058,AC9059|AC9012,AC9072|AC8204,AC9070|AC0301,AC3800|AC9009,AC9027|AC0300,AC8203|AC9032,AC9003|AC8001,AC2005|AC0004,AC8213|AC9050,AC9065|AC2503,AC4201|AC4200,AC9048|AC4000,AC2101|AC4100,AC8009|AC8005,AC8006|AC9045,AC9054|AC8214,AC3901|AC4500,AC9002|AC0101,AC8000|AC5200,AC5201|AC9000,AC9026|AC9077,AC0002|AC9033,AC9053|AC9001,AC9011|AC0400,AC0401|AC9016,AC9030|AC9035,AC9022|AC3100,AC8108|AC9068,AC9047|AC3900,AC8201|AC9067,AC9076|AC8102,AC8206|AC9069,AC9071|AC9061,AC9038|AC9028,AC9073|AC2502,AC3401|AC0100,AC2600|AC0102,AC3001|AC8007,AC8010|AC2103,AC8205|AC9017,AC9060|AC8013,AC9037|AC8200,AC8207|AC8011,AC5100|AC8101,AC8012|AC9052,AC9041|AC8107,AC9029|AC2002,AC3600|AC8014,AC8015|AC2000,AC2003|AC9023,AC9007|AC8216,AC8110|AC9006,AC9013|AC2004,AC8003|AC3200,AC9063|AC9051,AC0301|AC2001,AC9004|AC9049,AC0700|AC9063,AC9078|AC9079,AC9075";
const MB_DAYS = MB_RAW.split("|");

// Parse le catalogue de cafés en { ref -> nom }
const COFFEE_MAP = {};
CRAW.split("|").forEach(s => {
  const i = s.indexOf(" ");
  const ref = s.slice(0, i);
  const nm = s.slice(i + 1) + " Coffee";
  COFFEE_MAP[ref] = nm;
});

function getCoffeeName(ref) {
  return COFFEE_MAP[ref] || ref;
}

// Calcule les cafés du jour (même algo que getMB() dans l'app)
function getDailyCoffees() {
  // Utiliser l'heure de Paris pour le calcul
  const now = new Date();
  const paris = new Date(now.toLocaleString('en-US', { timeZone: 'Europe/Paris' }));
  const diff = Math.round(
    (Date.UTC(paris.getFullYear(), paris.getMonth(), paris.getDate()) -
      Date.UTC(2026, 2, 2)) /
      86400000
  );
  const idx = ((diff % MB_DAYS.length) + MB_DAYS.length) % MB_DAYS.length;
  const parts = MB_DAYS[idx].split(",");
  return {
    c1: getCoffeeName(parts[0]),
    c2: getCoffeeName(parts[1]),
    rupt: parts[2] ? getCoffeeName(parts[2]) : null
  };
}

// Tâches de shift selon le jour (même que SHIFT_DAILY + SHIFT_DAY dans index.html)
const SHIFT_DAILY = [
  "Vérifier mise en place carcasse/table/gobelets",
  "Pliage serviettes",
  "Mise en place plateaux",
  "Mise en place consoles",
  "Allumer le chariot et remplir",
  "Nettoyage et remplissage sucriers",
  "Remplissage vanille",
  "Parfumer la salle",
  "Nettoyage surface et guéridons: poussières"
];
const SHIFT_DAY = {
  1: ["Nettoyage rainures chaises", "Nettoyage consoles"],
  2: ["Nettoyage pieds de tables/chaises/accoudoirs", "Nettoyage machine à verre"],
  3: ["Nettoyage vitre", "Nettoyage chariot à pâtisseries complet"],
  4: ["Nettoyage placard office", "Nettoyage vestiaires"],
  5: ["Nettoyage frigo office", "Nettoyage desk hôtesses"],
  6: [],
  0: []
};

const JOURS_FR = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];
const MOIS_FR = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];

export default async () => {
  const token = process.env.TELEGRAM_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!token || !chatId) {
    console.error('[daily-summary] TELEGRAM_TOKEN ou TELEGRAM_CHAT_ID manquant');
    return;
  }

  const store = getStore('bacha-data');

  // ═══ Récupérer les données depuis Netlify Blobs ═══
  let rupt = [];
  let events = [];
  let stock = {};

  try { const r = await store.get('bacha_rupt', { type: 'json' }); if (Array.isArray(r)) rupt = r; } catch (e) { console.warn('rupt:', e.message); }
  try { const r = await store.get('bacha_events', { type: 'json' }); if (Array.isArray(r)) events = r; } catch (e) { console.warn('events:', e.message); }
  try { const r = await store.get('bacha_stock', { type: 'json' }); if (r && typeof r === 'object') stock = r; } catch (e) { console.warn('stock:', e.message); }

  // ═══ Heure de Paris ═══
  const now = new Date();
  const paris = new Date(now.toLocaleString('en-US', { timeZone: 'Europe/Paris' }));
  const jour = JOURS_FR[paris.getDay()];
  const dateStr = `${paris.getDate()} ${MOIS_FR[paris.getMonth()]} ${paris.getFullYear()}`;
  const todayISO = `${paris.getFullYear()}-${String(paris.getMonth() + 1).padStart(2, '0')}-${String(paris.getDate()).padStart(2, '0')}`;

  // ═══ 1. Cafés du jour ═══
  const daily = getDailyCoffees();
  let cofSection = `☕ *Cafés du jour*\n`;
  cofSection += `  • ${daily.c1.replace(' Coffee', '')}\n`;
  cofSection += `  • ${daily.c2.replace(' Coffee', '')}`;
  if (daily.rupt) {
    cofSection += `\n  🔄 _Remplacement rupture :_ ${daily.rupt.replace(' Coffee', '')}`;
  }

  // ═══ 2. Ruptures ═══
  let ruptSection = '';
  if (rupt.length > 0) {
    ruptSection = `\n\n🔴 *Ruptures (${rupt.length})*\n`;
    rupt.forEach(ref => {
      const name = getCoffeeName(ref).replace(' Coffee', '');
      ruptSection += `  • ${name} (${ref})\n`;
    });
    ruptSection = ruptSection.trimEnd();
  } else {
    ruptSection = `\n\n✅ *Aucune rupture en cours*`;
  }

  // ═══ 3. Stock bas (≤ 2 boîtes) ═══
  let stockSection = '';
  const lowStock = Object.entries(stock).filter(([, qty]) => typeof qty === 'number' && qty <= 2);
  if (lowStock.length > 0) {
    stockSection = `\n\n📦 *Stock bas (≤ 2)*\n`;
    lowStock.forEach(([ref, qty]) => {
      const name = getCoffeeName(ref).replace(' Coffee', '');
      const icon = qty === 0 ? '⚠️' : '🟡';
      stockSection += `  ${icon} ${name} : ${qty}\n`;
    });
    stockSection = stockSection.trimEnd();
  }

  // ═══ 4. Événements du jour ═══
  let evSection = '';
  const todayEvents = events.filter(ev => ev && ev.date === todayISO);
  if (todayEvents.length > 0) {
    evSection = `\n\n📅 *Événements aujourd'hui*\n`;
    todayEvents.forEach(ev => {
      const time = ev.time ? ` à ${ev.time}` : '';
      const guests = ev.guests ? ` — ${ev.guests} pers.` : '';
      evSection += `  🔔 *${ev.name || 'Événement'}*${time}${guests}\n`;
      if (ev.drinks && ev.drinks.length) {
        evSection += `    🧊 _À mettre au frais :_\n`;
        ev.drinks.forEach(d => {
          evSection += `      ${d.icon || '•'} ${d.label} — ${d.qty}${d.note ? ` (${d.note})` : ''}\n`;
        });
      }
      if (ev.items && ev.items.length) {
        evSection += `    🍸 _À servir :_\n`;
        ev.items.forEach(it => {
          evSection += `      • ${it.label}${it.qty ? ` — ${it.qty}` : ''}\n`;
        });
      }
    });
    evSection = evSection.trimEnd();
  }

  // ═══ 5. Tâches du jour (shift) ═══
  const dow = paris.getDay();
  const extraTasks = SHIFT_DAY[dow] || [];
  let taskSection = `\n\n🧹 *Tâches spéciales du jour*`;
  if (extraTasks.length > 0) {
    taskSection += `\n`;
    extraTasks.forEach(t => { taskSection += `  • ${t}\n`; });
    taskSection = taskSection.trimEnd();
  } else {
    taskSection += `\n  _Aucune tâche spéciale (${jour})_`;
  }

  // ═══ Assemblage du message ═══
  const header = `☀️ *Bonjour l'équipe !*\n${jour} ${dateStr}\n`;
  const separator = `─────────────────`;
  const text = `${header}${separator}\n\n${cofSection}${ruptSection}${stockSection}${evSection}${taskSection}\n\n${separator}\n_Bonne journée à toute l'équipe_ ☕✨`;

  // ═══ Envoi Telegram ═══
  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: 'Markdown'
      })
    });

    const data = await res.json();
    if (!res.ok) {
      console.error('[daily-summary] Telegram error:', data);
    } else {
      console.log('[daily-summary] Récap envoyé avec succès');
    }
  } catch (err) {
    console.error('[daily-summary] Envoi échoué:', err);
  }
};

// Configuration de la Scheduled Function
export const config = {
  schedule: "0 6 * * *"
};
