// /.netlify/functions/data
// Stockage cloud JSON via Netlify Blobs
// Usage :
//   GET  /.netlify/functions/data?key=stock       -> lit la clé "stock"
//   POST /.netlify/functions/data?key=stock       -> écrit la clé "stock" (body = JSON)
//   GET  /.netlify/functions/data?action=list     -> liste toutes les clés
//   DELETE /.netlify/functions/data?key=stock     -> supprime la clé

import { getStore } from '@netlify/blobs';

// Protection simple par mot de passe partagé (stocké en variable d'env)
function checkAuth(req) {
  const expected = process.env.APP_PASSWORD;
  if (!expected) return true; // pas de mot de passe configuré
  const provided = req.headers.get('x-app-password');
  return provided === expected;
}

export default async (req) => {
  if (!checkAuth(req)) {
    return new Response(JSON.stringify({ error: 'unauthorized' }), {
      status: 401,
      headers: { 'content-type': 'application/json' }
    });
  }

  const store = getStore('bacha-data');
  const url = new URL(req.url);
  const key = url.searchParams.get('key');
  const action = url.searchParams.get('action');

  try {
    if (action === 'list') {
      const { blobs } = await store.list();
      return Response.json({ keys: blobs.map((b) => b.key) });
    }

    if (!key) {
      return new Response(JSON.stringify({ error: 'key required' }), {
        status: 400,
        headers: { 'content-type': 'application/json' }
      });
    }

    if (req.method === 'GET') {
      const data = await store.get(key, { type: 'json' });
      return Response.json(data ?? null);
    }

    if (req.method === 'POST') {
      const body = await req.json();
      await store.setJSON(key, body);
      return Response.json({ ok: true, key });
    }

    if (req.method === 'DELETE') {
      await store.delete(key);
      return Response.json({ ok: true, key });
    }

    return new Response('method not allowed', { status: 405 });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { 'content-type': 'application/json' }
    });
  }
};
