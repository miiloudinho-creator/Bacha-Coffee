// /.netlify/functions/notify
// Envoi de notifications Telegram au groupe staff
// Usage : POST /.netlify/functions/notify { message, priority, author }

function checkAuth(req) {
  const expected = process.env.APP_PASSWORD;
  if (!expected) return true;
  const provided = req.headers.get('x-app-password');
  return provided === expected;
}

export default async (req) => {
  if (req.method !== 'POST') {
    return new Response('method not allowed', { status: 405 });
  }

  if (!checkAuth(req)) {
    return new Response(JSON.stringify({ error: 'unauthorized' }), {
      status: 401,
      headers: { 'content-type': 'application/json' }
    });
  }

  const token = process.env.TELEGRAM_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!token || !chatId) {
    return new Response(
      JSON.stringify({ error: 'TELEGRAM_TOKEN or TELEGRAM_CHAT_ID missing' }),
      { status: 500, headers: { 'content-type': 'application/json' } }
    );
  }

  const { message, priority = 'normal', author = '' } = await req.json();

  if (!message) {
    return new Response(JSON.stringify({ error: 'message required' }), {
      status: 400,
      headers: { 'content-type': 'application/json' }
    });
  }

  const icons = {
    low: 'ℹ️',
    normal: '📣',
    high: '⚠️',
    critical: '🚨'
  };
  const icon = icons[priority] || icons.normal;
  const authorLine = author ? `\n_par ${author}_` : '';
  const text = `${icon} *Bacha Companion*\n${message}${authorLine}`;

  const tgRes = await fetch(
    `https://api.telegram.org/bot${token}/sendMessage`,
    {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: 'Markdown'
      })
    }
  );

  const tgData = await tgRes.json();

  if (!tgRes.ok) {
    return new Response(JSON.stringify({ error: 'telegram failed', details: tgData }), {
      status: 500,
      headers: { 'content-type': 'application/json' }
    });
  }

  return Response.json({ ok: true });
};
