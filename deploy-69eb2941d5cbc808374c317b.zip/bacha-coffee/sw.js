// Service Worker - Bacha Coffee Companion
// Incrémente CACHE_VERSION à chaque déploiement majeur pour forcer le refresh
const CACHE_VERSION = 'bacha-v1';
const CORE_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/icons/icon-192.png',
  '/icons/icon-512.png'
];

// Installation : mise en cache des assets de base
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then((cache) => cache.addAll(CORE_ASSETS))
  );
  self.skipWaiting();
});

// Activation : nettoyage des vieux caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Fetch : stratégie network-first pour les Functions (données fraîches obligatoires),
// cache-first pour le reste (assets statiques)
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Jamais cacher les appels aux Netlify Functions : on veut toujours les données serveur
  if (url.pathname.startsWith('/.netlify/functions/')) {
    return; // laisse passer la requête réseau normale
  }

  // Pour tout le reste : cache d'abord, réseau en fallback
  event.respondWith(
    caches.match(event.request).then((cached) => {
      return (
        cached ||
        fetch(event.request).then((response) => {
          // Met en cache les nouveaux assets statiques rencontrés
          if (response.ok && event.request.method === 'GET') {
            const clone = response.clone();
            caches.open(CACHE_VERSION).then((cache) => cache.put(event.request, clone));
          }
          return response;
        })
      );
    })
  );
});
